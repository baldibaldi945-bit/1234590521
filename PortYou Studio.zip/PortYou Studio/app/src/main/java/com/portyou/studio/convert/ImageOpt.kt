package com.portyou.studio.convert

import java.io.File

/** No global sprite slicing or PNG post-processing: source dimensions and pages are retained. */
object ImagePost {
    fun run(modRoot: File, report: MutableList<String>) {
        report.add("images: original sheet dimensions preserved; sprite cutting and full-image post-processing disabled")
    }
}
