package com.portyou.studio.convert

import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.File

/** Lightweight metadata helpers. Adobe Animate SpriteMaps are kept native and are never rasterized. */
object Atlas {
    fun loadJson(f: File): JSONObject = JSONObject(f.readText().removePrefix("\uFEFF"))

    /** Check image bounds only; decoding every pixel of large atlases defeats fast conversion. */
    fun isPlaceholder(png: File): Boolean {
        if (!png.isFile) return true
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(png.path, bounds)
        return bounds.outWidth <= 4 && bounds.outHeight <= 4
    }

    /** A multi-page atlas is stripped only when every exported page is a placeholder. */
    fun atlasIsPlaceholder(folder: File): Boolean {
        val metas = folder.listFiles { file -> file.name.startsWith("spritemap") && file.name.endsWith(".json") } ?: return true
        if (metas.isEmpty()) return true
        for (json in metas) {
            val imageName = try {
                loadJson(json).optJSONObject("meta")?.optString("image", "").orEmpty()
            } catch (_: Exception) {
                ""
            }
            val pageSprites = try { loadJson(json).optJSONObject("ATLAS")?.optJSONArray("SPRITES")?.length() ?: 0 } catch (_: Exception) { 0 }
            if (pageSprites > 0) {
                val image = File(folder, imageName).takeIf { imageName.isNotEmpty() && it.isFile }
                    ?: File(json.path.removeSuffix(".json") + ".png")
                if (!isPlaceholder(image)) return false
            }
        }
        return true
    }

    /** (frameWidth, frameHeight) of the first Sparrow frame whose name starts with [prefix]. */
    fun sparrowFirstFrameSize(xmls: List<File>, prefix: String): Pair<Int, Int>? {
        for (xml in xmls) sparrowFirstFrameSize(xml, prefix)?.let { return it }
        return null
    }

    fun sparrowFirstFrameSize(xml: File?, prefix: String): Pair<Int, Int>? {
        if (xml == null || !xml.isFile) return null
        val tagRegex = Regex("<SubTexture\\b[^>]*>")
        for (match in tagRegex.findAll(xml.readText())) {
            val tag = match.value
            fun attr(name: String) = Regex("\\b$name=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
            if ((attr("name") ?: "").startsWith(prefix, ignoreCase = true)) {
                val width = (attr("frameWidth") ?: attr("width"))?.toDoubleOrNull() ?: return null
                val height = (attr("frameHeight") ?: attr("height"))?.toDoubleOrNull() ?: return null
                return width.toInt() to height.toInt()
            }
        }
        return null
    }
}
