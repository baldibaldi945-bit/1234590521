package com.portyou.studio

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("portyou", Context.MODE_PRIVATE)
    var lang: Int get() = sp.getInt("lang", Strings.EN); set(v) = sp.edit().putInt("lang", v).apply()
    var sfxMuted: Boolean get() = sp.getBoolean("sfxMuted", false); set(v) = sp.edit().putBoolean("sfxMuted", v).apply()
    var musicMuted: Boolean get() = sp.getBoolean("musicMuted", false); set(v) = sp.edit().putBoolean("musicMuted", v).apply()
    var phraseIdx: Int get() = sp.getInt("phraseIdx", 0); set(v) = sp.edit().putInt("phraseIdx", v).apply()
    var saveTree: String? get() = sp.getString("saveTree", null); set(v) = sp.edit().putString("saveTree", v).apply()
}
